# PDST
PLS DONATE Shop Timer tracks when the shop booths rotate in the Roblox game PLS DONATE!
